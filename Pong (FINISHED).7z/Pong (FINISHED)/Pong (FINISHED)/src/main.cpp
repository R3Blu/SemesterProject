#include <iostream>
#include <raylib.h>
using namespace std;


// Declaring SCORES:

int score1 = 0;
int score2 = 0;

// Classes for the main objects: 1) The BALL, 2) The PADDLES

class Ball
{
    public:
    float x, y;
    int speedX, speedY;
    int radius;

    // Function to 1) reset the ball to the MIDDLE OF THE SCREEN, and 2) randomise the direction of its speed to any diagonal direction
    void Reset()
        {
            // Resetting the position of the ball to the middle of the screen
            x = GetScreenWidth()/2;
            y = GetScreenHeight()/2;

            // Randomising the speed in a random diagonal direction
            int speed_choice[2] = {-1, 1};
            speedX *= speed_choice[GetRandomValue (0,1)];
            speedY *= speed_choice[GetRandomValue (0,1)];
        }

    void Draw() // Function to DRAW THE BALL
    {
        DrawCircle (x, y, radius, ORANGE);
    }

    // Function to UPDATE THE POSITION OF THE BALL with EACH PASSING FRAME

    void Update()
    {
        // Declaring the Vertical (x) & Diagonal (y) speeds of the ball
        x += speedX;
        y += speedY;

        if (y + radius >= GetScreenHeight() || y - radius <= 0) // Bouncing the ball back when it hits the top or bottom of the screen
        {
            speedY *= -1; // Reverses the vertical speed of the ball, so that it appears to 'bounce' from its original trajectory
        }

        if (x + radius >= GetScreenWidth()) //  Giving a point to Player 1, if the ball hits the RIGHT side of the screen
        {
            Reset(); // Runs the Reset() function
            score1 ++;
        }

        if (x - radius <= 0) //  Giving a point to Player 2, if the ball hits the LEFT side of the screen
        {
            Reset(); // Runs the Reset() function
            score2 ++;
        }
    }
};

// The paddle used by player 1:

class Paddle1
{
    public:
    float x, y; // Coordinates of the top-left corner of the paddle
    float width, height; // Dimensions of the paddle
    int speed; // Vertical speed of the paddle

    void Draw() // Function to DRAW THE PADDLE
    {
        DrawRectangle (x, y, width, height, RED); 
    }

    void Update() // Function to UPDATE THE PADDLE'S POSITION
    {

        // The next 2 if() statements stop the paddle from moving out of the screen

        if (y <= 0) 
        {
            y = 0;
        }

        if (y + height >= GetScreenHeight())
        {
            y = GetScreenHeight() - height;
        }

        // The next 2 if() statements make the paddle move up & down, depending on what key the player holds down (W or S)

        if (IsKeyDown (KEY_S))
        {
            y += speed;
        }

        if (IsKeyDown (KEY_W))
        {
            y -= speed;
        }
    }
};

class Paddle2 // Same code as before for the second paddle, with the only difference being the movements controls
{
    public:
    float x, y;
    float width, height;
    int speed;

    void Draw()
    {
        DrawRectangle (x, y, width, height, RED);
    }

    void Update()
    {
        if (y <= 0)
        {
            y = 0;
        }

        if (y + height >= GetScreenHeight())
        {
            y = GetScreenHeight() - height;
        }

        // The next 2 if() statements make the paddle move up & down, depending on what key the player holds down (Arrow Keys)

        if (IsKeyDown (KEY_DOWN))
        {
            y += speed;
        }

        if (IsKeyDown (KEY_UP))
        {
            y -= speed;
        }
    }
};

// Declaring  the objects for the ball, first paddle, and second paddle

Ball ball; 
Paddle1 player1;
Paddle2 player2;

// Main function

int main()
{
    cout << "Starting the game..." << endl;

    // Basic settings for the game window

    const int screen_width = 1280;
    const int screen_height = 800;
    InitWindow(screen_width, screen_height, "Pong");
    SetTargetFPS (60);

    // INITIAL PROPERTIES FOR THE BALL:

    ball.radius = 20;
    ball.x = screen_width/2;
    ball.y = screen_height/2;
    ball.speedX = 7;
    ball.speedY = 7;

    // INITIAL PADDLE PROPERTIES FOR PLAYER 1:

    player1.width = 25;
    player1.height = 120;
    player1.x = 10;
    player1.y = (screen_height/2) - (player1.height/2);
    player1.speed = 6;

    // INITIAL PADDLE PROPERTIES FOR PLAYER 2:

    player2.width = 25;
    player2.height = 120;
    player2.x = GetScreenWidth() - player2.width - 10;
    player2.y = (screen_height/2) - (player1.height/2);
    player2.speed = 6;

    // GAME LOOP: This will keep repeating with every passing frame. It contains all the events & actions that will occur in the game
    while ((score1 < 5) && (score2 < 5))  // The loop will only stop if a player WINS by getting five points.
    {
        ClearBackground (DARKBLUE); // Erases everything from the previous frame, to start the loop afresh

        // Drawing:

        BeginDrawing();

        // Drawing the paddles

        player1.Draw();
        player2.Draw();

        // Drawing the ball

        ball.Draw();

        // Drawing the scores

        DrawText(TextFormat("%i", score1), screen_width/2 - 250, 10, 80, GREEN);
        DrawText(TextFormat("%i", score2), screen_width/2 + 250, 10, 80, GREEN);

        // Drawing the net

        DrawLine (screen_width/2, 0, screen_width/2, screen_height, WHITE);

        // Updating Positions by using the  Update() functions declared beforehand:

        player1.Update();
        player2.Update();
        ball.Update();

        // Special update sequence if the ball hits either paddle

        if (CheckCollisionCircleRec (Vector2 {ball.x, ball.y}, ball.radius, Rectangle {player1.x, player1.y, player1.width, player1.height}))
        {
            ball.speedX *= -1;
        }

        if (CheckCollisionCircleRec (Vector2 {ball.x, ball.y}, ball.radius, Rectangle {player2.x, player2.y, player2.width, player2.height}))
        {
            ball.speedX *= -1;
        }

        // Stopping Drawing

        EndDrawing();

        // if() statement which closes the game if either 1) 'esc' or 2) the close button is pressed

        if (WindowShouldClose() == true)
        break;
    }

    ClearBackground (DARKBLUE); // Erases everything from the previous while loop

    // NEW LOOP which displays the winner

    while (WindowShouldClose() == false) // Another smaller game loop which displays the winner until the player presses 'esc' or the close button.
    {
        BeginDrawing();

        ClearBackground (DARKGRAY); // Erases everything from the previous frame

        DrawText (TextFormat ("%s", "Here is your winner..."), screen_width/3 - 140, screen_height/2 - 200, 70, BLUE);

        if (score1 >= 5) // Code to execute if Player 1 gets five points
        DrawText (TextFormat ("%s", "PLAYER 1!!!!!"), screen_width/3 - 80, screen_height/2 + 200, 100, YELLOW);

        if (score2 >= 5) // Code to execute if Player 2 gets five points
        DrawText (TextFormat ("%s", "PLAYER 2!!!!!"), screen_width/3 - 80, screen_height/2 + 200, 100, YELLOW);

        EndDrawing();
    }


    CloseWindow(); // Closes the game after the above while() loop is broken
    return 0;
}